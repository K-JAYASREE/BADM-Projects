
ALTER TABLE patients 
ADD CONSTRAINT PRIMARY KEY(patient_id);

ALTER TABLE doctors 
ADD CONSTRAINT PRIMARY KEY(doctor_id);

ALTER TABLE appointments 
ADD CONSTRAINT PRIMARY KEY (appointment_id), 
ADD CONSTRAINT FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
ADD CONSTRAINT FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id);

ALTER TABLE diagnoses
ADD CONSTRAINT PRIMARY KEY (diagnosis_id), 
ADD CONSTRAINT FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
ADD CONSTRAINT FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id);

ALTER TABLE medications
ADD CONSTRAINT PRIMARY KEY (medication_id), 
ADD CONSTRAINT FOREIGN KEY (diagnosis_id) REFERENCES diagnoses(diagnosis_id);

DELETE FROM medications
WHERE start_date > end_date;

DELETE hm
FROM healthcare.medications hm
JOIN healthcare.diagnoses hdg ON hm.diagnosis_id = hdg.diagnosis_id
JOIN healthcare.appointments ha ON hdg.patient_id = ha.patient_id
WHERE hm.end_date < ha.appointment_date;

DELETE hm
FROM healthcare.medications hm
JOIN healthcare.diagnoses hdg ON hm.diagnosis_id = hdg.diagnosis_id
WHERE hm.end_date < hdg.diagnosis_date;

SELECT * FROM medications;

-- TASK_1: Write a query to fetch details of all completed appointments, including the patient’s name, doctor’s name, and specialization.

SELECT hd.name AS Doctor_Name, hd.specialization, hp.Patient_Name, ha.status
FROM healthcare.appointments ha 
JOIN healthcare.doctors hd ON ha.doctor_id = hd.doctor_id 
JOIN healthcare.patients hp ON ha.patient_id = hp.patient_id
WHERE ha.status = "Completed";

-- TASK-2: Retrieve all patients who have never had an appointment. Include their name, contact details, and address in the output.

SELECT hp.*
FROM healthcare.patients hP
LEFT JOIN healthcare.appointments ha ON hp.patient_id = ha.patient_id
WHERE ha.appointment_id IS NULL ;

-- TASK-3: Find the total number of diagnoses for each doctor, including doctors who haven’t diagnosed any patients. 

-- Display the doctor’s name, specialization, and total diagnoses.
SELECT hd.name AS Doctor_Name, hd.specialization, COUNT(hda.diagnosis_id) as total_diagnoses
FROM healthcare.doctors hd 
RIGHT JOIN healthcare.diagnoses hda ON hd.doctor_id = hda.doctor_id
GROUP BY hd.name, hd.specialization;

-- TASK-4: Write a query to identify mismatches between the appointments and diagnoses tables. 
-- Include all appointments and diagnoses with their corresponding patient and doctor details.

-- Appointments without Matching Diagnoses
SELECT ha.appointment_id, ha.patient_id, ha.doctor_id, ha.appointment_date, hdg.diagnosis_id, hdg.diagnosis_date, 'Appointment Without Diagnosis' AS mismatch_type
FROM healthcare.appointments ha
LEFT JOIN healthcare.diagnoses hdg ON ha.patient_id = hdg.patient_id AND ha.doctor_id = hdg.doctor_id
WHERE hdg.diagnosis_id IS NULL
UNION
-- Diagnoses without Matching Appointments
SELECT hdg.diagnosis_id, hdg.patient_id, hdg.doctor_id, NULL AS appointment_date, ha.appointment_id, ha.appointment_date, 'Diagnosis Without Appointment' AS mismatch_type
FROM healthcare.diagnoses hdg
LEFT JOIN healthcare.appointments ha ON hdg.patient_id = ha.patient_id AND hdg.doctor_id = ha.doctor_id
WHERE ha.appointment_id IS NULL;

-- TASK-5: For each doctor, rank their patients based on the number of appointments in descending order.

WITH DoctorAppointmentCounts 
AS (SELECT a.doctor_id, d.name AS doctor_name, d.specialization, COUNT(a.appointment_id) AS total_appointments
FROM healthcare.appointments a 
JOIN healthcare.doctors d ON a.doctor_id = d.doctor_id
GROUP BY a.doctor_id, d.name, d.specialization)
SELECT doctor_id, doctor_name, specialization, total_appointments,
RANK() OVER (ORDER BY total_appointments DESC) AS rank_position
FROM DoctorAppointmentCounts;

-- TASK-6: Write a query to categorize patients by age group (e.g., 18-30, 31-50, 51+). Count the number of patients in each age group.

SELECT 
    CASE 
        WHEN age BETWEEN 18 AND 30 THEN '18-30'
        WHEN age BETWEEN 31 AND 50 THEN '31-50'
        WHEN age >= 51 THEN '51+'
        ELSE 'Unknown'
    END AS age_group,
    COUNT(*) AS total_patients
FROM healthcare.patients
GROUP BY age_group;

-- TASK-7: Retrieve a list of patients whose contact numbers end with "1234" and display their names in uppercase.
SELECT UPPER(patient_name) AS patient_name, contact_number
FROM healthcare.patients
WHERE contact_number LIKE '%1234';

-- TASK-8: Find patients who have only been prescribed "Insulin" in any of their diagnoses.

SELECT p.patient_id, p.Patient_Name
FROM healthcare.patients p
WHERE p.patient_id IN (
    SELECT d.patient_id
    FROM healthcare.diagnoses d
    JOIN healthcare.medications m ON d.diagnosis_id = m.diagnosis_id
    WHERE m.medication_name = 'Insulin'
    GROUP BY d.patient_id
    HAVING COUNT(DISTINCT m.medication_name) = 1
);

-- TASK:9 Calculate the average duration (in days) for which medications are prescribed for each diagnosis.
SELECT diagnosis_id, AVG(DATEDIFF(end_date, start_date)) AS avg_duration_days
FROM healthcare.medications
WHERE end_date IS NOT NULL AND start_date IS NOT NULL
GROUP BY diagnosis_id;

-- TASK-10: Write a query to identify the doctor who has attended the most unique patients. 
-- Include the doctor’s name, specialization, and the count of unique patients.
WITH DoctorPatientCounts AS (
SELECT ha.doctor_id,
COUNT(DISTINCT ha.patient_id) AS unique_patient_count
FROM healthcare.appointments ha
GROUP BY ha.doctor_id)
SELECT hd.doctor_id, hd.name AS doctor_name, hd.specialization, dc.unique_patient_count
FROM DoctorPatientCounts dc
JOIN healthcare.doctors hd ON dc.doctor_id = hd.doctor_id
ORDER BY dc.unique_patient_count DESC;